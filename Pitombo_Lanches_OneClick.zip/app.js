const express = require('express');
const { Pool } = require('pg');
const dotenv = require('dotenv');
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Postgres Pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false
});

// Test DB connection on startup
(async () => {
  try {
    const client = await pool.connect();
    console.log('✅ Postgres conectado com sucesso');
    client.release();
  } catch (err) {
    console.error('❌ Erro ao conectar no Postgres:', err.message);
  }
})();

app.get('/', (req, res) => {
  res.send('🚀 Pitombo Lanches — servidor OK');
});

// Listar produtos (seed do schema)
app.get('/products', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, name, price_cents FROM pitombo.products ORDER BY name');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'DB error' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor Pitombo Lanches rodando em http://localhost:${PORT}`);
});
