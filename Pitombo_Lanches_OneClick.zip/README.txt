PITOMBO LANCHES — PACOTE 1-CLIQUÉ (LOCAL)

1) PRÉ-REQUISITOS
- Node.js instalado (node -v)
- PostgreSQL + pgAdmin instalados
- Banco criado no pgAdmin: pitombo_db
- Usuário (opcional): pitombo_user com senha definida

2) CONFIGURAR .ENV
- Copie .env.example para .env
- Edite a linha:
  DATABASE_URL=postgresql://pitombo_user:SUA_SENHA@localhost:5432/pitombo_db

3) CRIAR TABELAS NO PGADMIN
- Abra pgAdmin, selecione pitombo_db
- Tools > Query Tool
- Copie o conteúdo de db/pitombo_schema.sql e clique em Run ▶

4) INSTALAR E RODAR
No terminal, dentro da pasta do projeto:
  npm install
  node app.js

Abra no navegador:
  http://localhost:3000         -> servidor OK
  http://localhost:3000/products -> lista de produtos (seed)

5) PROBLEMAS COMUNS
- ECONNREFUSED / autenticação: confira a DATABASE_URL no .env
- relation pitombo.products does not exist: execute o pitombo_schema.sql no banco certo
- Porta ocupada: troque PORT no .env
