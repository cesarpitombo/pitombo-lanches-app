-- pitombo_schema.sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE SCHEMA IF NOT EXISTS pitombo;
SET search_path = pitombo, public;

CREATE TABLE IF NOT EXISTS users (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT,
  password_hash TEXT,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS categories (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT
);

CREATE TABLE IF NOT EXISTS products (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price_cents INT NOT NULL,
  category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  customer_id UUID REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending',
  total_cents BIGINT DEFAULT 0,
  payment_method TEXT,
  address JSONB,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id),
  name TEXT,
  unit_price_cents INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  total_price_cents BIGINT GENERATED ALWAYS AS (unit_price_cents * quantity) STORED
);

-- Seeds
INSERT INTO categories (name, slug) VALUES
('Lanches','lanches'),('Bebidas','bebidas')
ON CONFLICT DO NOTHING;

INSERT INTO products (name, description, price_cents, category_id)
SELECT 'X-Burger','Hambúrguer com queijo',750,c.id FROM categories c WHERE c.slug='lanches' LIMIT 1;
INSERT INTO products (name, description, price_cents, category_id)
SELECT 'Refrigerante 350ml','Lata 350ml',250,c.id FROM categories c WHERE c.slug='bebidas' LIMIT 1;

INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Administrador','admin@pitombo.local','+351000000000','changeme-hash','admin')
ON CONFLICT (email) DO NOTHING;
